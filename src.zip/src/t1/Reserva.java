package t1;

public class Reserva extends Biblioteca {
    public Livro livro;
    public Usuario usuario;
}
