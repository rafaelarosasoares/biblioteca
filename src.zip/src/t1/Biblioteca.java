package t1;

public abstract class Biblioteca {
    public Integer id;
}
