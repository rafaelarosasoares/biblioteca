package t1;

public class Multa {
    public Double valor;
    public Boolean pago = false;
}
