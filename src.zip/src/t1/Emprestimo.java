package t1;

import java.sql.Date;

public class Emprestimo extends Biblioteca {
    public Livro livro;
    public Usuario usuario;
    public Date prazo;
    public Date devolucao;
}
