package t1;

public class Livro extends Biblioteca {
    public String titulo;
    public String isbn;
    public Integer ano;
    public String autores;
    public String editora;
    public Integer edicao;
}
