/**
 * 
 */
/**
 * @author Dell
 *
 */
module t1 {
	requires java.sql;
}